﻿using System;
using System.Collections.Generic;

#nullable disable

namespace projectloanapplication_api.Models
{
    public partial class TblMasterLoantype
    {
        public int LoanTypeId { get; set; }
        public string LoanName { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using projectloanapplication.Helper;
using projectloanapplication.Models;

namespace projectloanapplication.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }
        LoanApplicationAPI _api = new LoanApplicationAPI();

        //List 
        public async Task<IActionResult> LoanReport()
        {
            List<TblLoanapplication> studentDatas = new List<TblLoanapplication>();
            HttpClient cli = _api.Initial();
            HttpResponseMessage result = await cli.GetAsync("api/TblLoanapplications");
            if (result.IsSuccessStatusCode)
            {
                var res = result.Content.ReadAsStringAsync().Result;
                studentDatas = JsonConvert.DeserializeObject<List<TblLoanapplication>>(res);
            }


            return View(studentDatas);
        }
        //Create New
        public async Task<IActionResult> ApplicationForm()
        {
            List<TblMasterJob> studentDatas = new List<TblMasterJob>();
            List<TblMasterLoantype> loantypes = new List<TblMasterLoantype>();
            HttpClient cli = _api.Initial();
            HttpResponseMessage result = await cli.GetAsync("api/TblMasterJobs");
            HttpResponseMessage loanresult = await cli.GetAsync("api/TblMasterLoantypes");
            if (result.IsSuccessStatusCode)
            {
                var res = result.Content.ReadAsStringAsync().Result;
                studentDatas = JsonConvert.DeserializeObject<List<TblMasterJob>>(res);
                ViewBag.JobType = new SelectList(studentDatas, "JobName", "JobName");
            }
            if(loanresult.IsSuccessStatusCode)
            {
                var loan = loanresult.Content.ReadAsStringAsync().Result;
                loantypes = JsonConvert.DeserializeObject<List<TblMasterLoantype>>(loan);
                ViewBag.LoanType = new SelectList(loantypes, "LoanName", "LoanName");
            }
            return View();

        }

        [HttpPost]
        public async Task<IActionResult> ApplicationForm(TblLoanapplication student)
        {
            HttpClient cli = _api.Initial();
            string authornew = JsonConvert.SerializeObject(student);
            StringContent content = new StringContent(authornew, Encoding.UTF8, "application/json");
            HttpResponseMessage response = cli.PostAsync(cli.BaseAddress + "api/TblLoanapplications", content).Result;
            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction("LoanReport");
            }
            return View();

        }

        public async Task<IActionResult> ApplicationDetail(int id)
        {
            var student = new TblLoanapplication();
            HttpClient cli = _api.Initial();
            HttpResponseMessage result = await cli.GetAsync($"api/TblLoanapplications/{id}");
            if (result.IsSuccessStatusCode)
            {
                var res = result.Content.ReadAsStringAsync().Result;
                student = JsonConvert.DeserializeObject<TblLoanapplication>(res);
            }
            return View(student);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}

﻿using System;
using System.Collections.Generic;

#nullable disable

namespace projectloanapplication.Models
{
    public partial class TblMasterLoantype
    {
        public int LoanTypeId { get; set; }
        public string LoanName { get; set; }
    }
}

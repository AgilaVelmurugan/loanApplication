﻿using System;
using System.Collections.Generic;

#nullable disable

namespace projectloanapplication.Models
{
    public partial class TblMasterJob
    {
        public int JobId { get; set; }
        public string JobName { get; set; }
    }
}
